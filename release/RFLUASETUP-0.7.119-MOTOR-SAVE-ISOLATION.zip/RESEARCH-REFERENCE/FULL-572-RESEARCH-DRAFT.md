# 전체 572개 기어비 연구 초안

확인 468개, 미확인 초안 104개. 전체 항목을 수록했다는 뜻이며 기어비 572개가 모두 검증됐다는 뜻은 아닙니다. 원본 확인 자료와 설치본은 변경하지 않았습니다.

GT500 FBL TT 참고값: 메인162T / 피니언13T = 12.461538:1, 테일 표기4.68:1, 테일 구동기어31T. 원판매자 미확보의 2차 목록 값으로, 확정 기본값이나 FC 자동 적용 대상이 아닙니다.

| 브랜드 | 모델 | 상태 | 확인 프로필 | 부품 기록 |
|---|---|---|---:|---:|
| ALIGN | T-REX 150 DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 150X | 확인 | 1 | 0 |
| ALIGN | T-REX 150X TA | 확인 | 1 | 0 |
| ALIGN | T-Rex 250 | 확인 | 1 | 0 |
| ALIGN | T-REX 250 Plus DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 250 PRO DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 250 SE | 확인 | 1 | 0 |
| ALIGN | T-REX 300X | 확인 | 1 | 0 |
| ALIGN | T-REX 450 PLUS DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 450 PRO | 확인 | 3 | 0 |
| ALIGN | T-REX 450 PRO V2 | 확인 | 1 | 0 |
| ALIGN | T-REX 450 SA | 확인 | 4 | 0 |
| ALIGN | T-REX 450 SE | 확인 | 4 | 0 |
| ALIGN | T-REX 450 SE V2 | 확인 | 3 | 0 |
| ALIGN | T-REX 450 Sport | 확인 | 1 | 0 |
| ALIGN | T-REX 450 Sport V2 | 확인 | 3 | 0 |
| ALIGN | T-REX 450 XL | 확인 | 4 | 0 |
| ALIGN | T-REX 450L Dominator 6S | 확인 | 1 | 0 |
| ALIGN | T-REX 450L Dominator KIT 6S (RH45E23XW) | 확인 | 1 | 0 |
| ALIGN | T-REX 450LP | 확인 | 1 | 0 |
| ALIGN | T-REX 470LM | 확인 | 1 | 0 |
| ALIGN | T-REX 470LP | 확인 | 1 | 0 |
| ALIGN | T-REX 470LT | 확인 | 1 | 0 |
| ALIGN | T-REX 500 CF | 확인 | 1 | 0 |
| ALIGN | T-REX 500 ESP | 확인 | 1 | 0 |
| ALIGN | T-REX 500 PRO DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 500E PRO | 확인 | 1 | 0 |
| ALIGN | T-REX 500EFL PRO 3GX | 확인 | 1 | 0 |
| ALIGN | T-REX 500L Dominator | 확인 | 1 | 0 |
| ALIGN | T-REX 500X | 확인 | 1 | 0 |
| ALIGN | T-REX 500XT | 확인 | 1 | 0 |
| ALIGN | T-REX 550E | 확인 | 4 | 0 |
| ALIGN | T-REX 550E (KX021002T / 2010) | 확인 | 1 | 0 |
| ALIGN | T-REX 550E (KX021005T / 16T) | 확인 | 3 | 0 |
| ALIGN | T-REX 550E (KX021005T / 17T) | 확인 | 3 | 0 |
| ALIGN | T-REX 550E 3GX | 확인 | 2 | 0 |
| ALIGN | T-REX 550E 3GX (KX021008AT / 112T) | 확인 | 1 | 0 |
| ALIGN | T-REX 550E DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 550E PRO DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 550E V2 | 확인 | 2 | 0 |
| ALIGN | T-REX 550E V2 (KX021007AT / 112T) | 확인 | 1 | 0 |
| ALIGN | T-REX 550L Dominator | 확인 | 1 | 0 |
| ALIGN | T-REX 550X | 확인 | 1 | 0 |
| ALIGN | T-REX 600 ESP | 확인 | 3 | 0 |
| ALIGN | T-REX 600 Nitro | 확인 | 1 | 0 |
| ALIGN | T-REX 600 Nitro DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 600 Nitro V2 | 확인 | 2 | 0 |
| ALIGN | T-REX 600 Nitro V2 Limited Edition | 확인 | 3 | 0 |
| ALIGN | T-REX 600E PRO | 확인 | 1 | 0 |
| ALIGN | T-REX 600EFL PRO | 확인 | 1 | 0 |
| ALIGN | T-REX 600L Dominator | 확인 | 1 | 0 |
| ALIGN | T-REX 600XN | 확인 | 1 | 0 |
| ALIGN | T-REX 650X | 확인 | 1 | 0 |
| ALIGN | T-REX 700 Nitro | 확인 | 1 | 0 |
| ALIGN | T-REX 700 Nitro DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 700 Nitro Pro | 확인 | 1 | 0 |
| ALIGN | T-REX 700E | 확인 | 1 | 0 |
| ALIGN | T-REX 700E 3GX | 확인 | 1 | 0 |
| ALIGN | T-REX 700E DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 700E DFC HV | 확인 | 1 | 0 |
| ALIGN | T-REX 700E F3C | 확인 | 1 | 0 |
| ALIGN | T-REX 700E F3C V2 | 확인 | 1 | 0 |
| ALIGN | T-REX 700E PRO DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 700E PRO DFC HV | 확인 | 1 | 0 |
| ALIGN | T-REX 700L Dominator | 확인 | 1 | 0 |
| ALIGN | T-REX 700L Dominator HV | 확인 | 1 | 0 |
| ALIGN | T-REX 700L Dominator TOP | 확인 | 1 | 0 |
| ALIGN | T-REX 700L V2 | 확인 | 1 | 0 |
| ALIGN | T-REX 700X | 확인 | 1 | 0 |
| ALIGN | T-REX 700XN | 확인 | 1 | 0 |
| ALIGN | T-REX 700XP | 확인 | 1 | 0 |
| ALIGN | T-REX 760X | 확인 | 1 | 0 |
| ALIGN | T-REX 800E DFC | 확인 | 1 | 0 |
| ALIGN | T-REX 800E DFC Trekker | 확인 | 1 | 0 |
| ALIGN | T-REX 800E F3C | 확인 | 1 | 0 |
| ALIGN | T-REX 800E PRO | 확인 | 1 | 0 |
| ALIGN | T-REX 800E PRO DFC | 확인 | 1 | 0 |
| ALIGN | T-REX700E F3C V3 | 확인 | 1 | 0 |
| ALIGN | T15 | 확인 | 1 | 0 |
| ALIGN | T15 TA | 확인 | 1 | 0 |
| ALIGN | TB40 | 확인 | 3 | 0 |
| ALIGN | TB60 | 확인 | 1 | 0 |
| ALIGN | TB60 12S | 확인 | 1 | 0 |
| ALIGN | TB60 6S | 확인 | 1 | 0 |
| ALIGN | TB70 | 확인 | 3 | 0 |
| ALIGN | TB70 (Top Combo / Kit) | 확인 | 3 | 0 |
| ALIGN | TB70 Super Combo | 확인 | 1 | 0 |
| ALIGN | TB70 V2 Top Combo | 확인 | 1 | 0 |
| ALIGN | TN70 | 확인 | 1 | 0 |
| ALZRC | Devil 380 FAST | 확인 | 3 | 0 |
| ALZRC | Devil 450 Pro V2 | 확인 | 1 | 0 |
| ALZRC | Devil 505 FAST | 확인 | 11 | 0 |
| ALZRC | Devil R42 | 확인 | 7 | 0 |
| ALZRC | Devil X360 | 확인 | 6 | 0 |
| ALZRC | Devil X380 | 확인 | 1 | 0 |
| Avant | Mostro 700 Electric | 확인 | 5 | 0 |
| Banshee | Banshee 700 Limited | 확인 | 3 | 0 |
| Banshee | Banshee 850 | 확인 | 3 | 0 |
| BEAM | 4.8 ACRO / Acro 480 | 확인 | 4 | 0 |
| BEAM | Aquila 550 | 확인 | 1 | 0 |
| BEAM | Archon SE | 확인 | 1 | 0 |
| BEAM | E4 | 확인 | 3 | 0 |
| BEAM | E4 450 SE | 확인 | 6 | 0 |
| BEAM | E5 Archon 500 | 확인 | 5 | 0 |
| BEAM | E6 Avantgarde V2 | 확인 | 4 | 0 |
| BEAM | Monster 5.0 | 확인 | 1 | 0 |
| BEAM | Monster 5.0 Stretch | 확인 | 1 | 0 |
| BEAM | Monster 7.0 (700) | 확인 | 5 | 0 |
| FLYWING | FW450L ACE | 확인 | 1 | 0 |
| GAUI | Hurricane 425 | 확인 | 17 | 0 |
| GAUI | Hurricane 550 | 확인 | 4 | 0 |
| GAUI | NX4 | 확인 | 1 | 0 |
| GAUI | NX7 | 확인 | 1 | 0 |
| GAUI | R5 V2 | 확인 | 1 | 0 |
| GAUI | X3 | 확인 | 6 | 0 |
| GAUI | X3L | 확인 | 3 | 0 |
| GAUI | X4 | 확인 | 1 | 0 |
| GAUI | X4 II | 확인 | 7 | 0 |
| GAUI | X5 | 확인 | 5 | 0 |
| GAUI | X5 FES | 확인 | 5 | 0 |
| GAUI | X5 Formula | 확인 | 5 | 0 |
| GAUI | X7 | 확인 | 5 | 0 |
| GAUI | X7 FZ | 확인 | 1 | 0 |
| GOOSKY | E2 | 확인 | 1 | 0 |
| GOOSKY | E2-GPS | 확인 | 1 | 0 |
| GOOSKY | RS5 | 확인 | 3 | 0 |
| GOOSKY | RS6 | 확인 | 3 | 0 |
| GOOSKY | RS7 | 확인 | 5 | 0 |
| GOOSKY | RS7 Ultra | 확인 | 5 | 0 |
| GOOSKY | S1 | 확인 | 1 | 0 |
| GOOSKY | S2 | 확인 | 1 | 0 |
| GOOSKY | S2 Max | 확인 | 1 | 0 |
| GOOSKY | S2 Ultra | 확인 | 1 | 0 |
| Hirobo | 30 SCALE iroquois BELL UH-1B [0412-933] | 확인 | 1 | 0 |
| Hirobo | 30 SCALE Schweizer 300 [0412-959] | 확인 | 1 | 0 |
| Hirobo | 70-90 SCALE eurocopter EC120B Colibri [0414-911] | 확인 | 1 | 2 |
| Hirobo | 70-90 Scale eurocopter ec135 [0404-991] | 확인 | 1 | 2 |
| Hirobo | BELL 47G GS [0405-909] | 확인 | 1 | 5 |
| Hirobo | (生産終了) EAGLE4 EP SSLⅢ [0307-905] | 확인 | 1 | 5 |
| Hirobo | EMBLA 450E [0304-910] | 확인 | 1 | 9 |
| Hirobo | Freya | 확인 | 3 | 0 |
| Hirobo | Freya 60 | 확인 | 1 | 4 |
| Hirobo | Freya 90 | 확인 | 1 | 4 |
| Hirobo | FREYA EVO OP SWM SSLⅡ [0414-949] | 확인 | 1 | 8 |
| Hirobo | Freya Evolution 90 | 확인 | 1 | 8 |
| Hirobo | FREYA Evolution OP SWM SSZ-V (for GT15HZ) [0414-948] | 확인 | 1 | 9 |
| Hirobo | Freya X-Spec | 확인 | 3 | 0 |
| Hirobo | Gigas 550E | 확인 | 4 | 0 |
| Hirobo | Gigas 550E [0308-901] | 확인 | 4 | 0 |
| Hirobo | Lama S30.mech | 확인 | 1 | 0 |
| Hirobo | 30 Scale lama SA-315B red [0412-930] | 확인 | 1 | 0 |
| Hirobo | 30 Scale lama SA-315B red [0412-968] | 확인 | 1 | 0 |
| Hirobo | 30 Scale lama SA-315B white [0412-931] | 확인 | 1 | 0 |
| Hirobo | Sceadu | 확인 | 3 | 0 |
| Hirobo | Sceadu 30 | 확인 | 1 | 5 |
| Hirobo | Sceadu 50 | 확인 | 1 | 5 |
| Hirobo | Sceadu Evolution 30 | 확인 | 1 | 7 |
| Hirobo | Sceadu Evolution 50 | 확인 | 1 | 7 |
| Hirobo | Schweizer 300 | 확인 | 1 | 1 |
| Hirobo | [0412-969] 30スケール Schweizer300 MRB-ⅢメタルR/H仕様 | 확인 | 1 | 0 |
| Hirobo | SDX 50 HPM KIT B/M LESS [0403-970] | 확인 | 1 | 0 |
| Hirobo | SDX 50 SWM FL-Ⅱ B/M LESS [0403-972] | 확인 | 1 | 7 |
| Hirobo | [0403-971] SDX 50 SWM FZ-Ⅴ B/M LESS | 확인 | 1 | 7 |
| Hirobo | SDX D3 SWM SL -Ⅱ [0403-969] | 확인 | 1 | 6 |
| Hirobo | Shuttle Plus | 확인 | 1 | 2 |
| Hirobo | Shuttle シャトル Plus+2 エンジン/マフラーレス 半完成 [0412-971] | 확인 | 1 | 0 |
| Hirobo | Shuttle シャトル Plus+2 エンジン/マフラーレス 半完成 [0412-978] | 확인 | 1 | 0 |
| Hirobo | Shuttle シャトル Plus+2 半完成(OS32SX-H) エンジン付 [0412-970] | 확인 | 1 | 0 |
| Hirobo | Shuttle Plus+2 EP FL SWM XX 70周年記念 [0305-906] | 확인 | 1 | 0 |
| Hirobo | Shuttle Plus+2 EP FL SWM XX 組立キット [0305-903] | 확인 | 1 | 1 |
| Hirobo | Shuttle Plus+2 kit [0412-962] | 확인 | 1 | 0 |
| Hirobo | Shuttle シャトル Plus+2XX 70周年記念モデル 組立キット [0412-972] | 확인 | 1 | 2 |
| Hirobo | Shuttle Z | 확인 | 1 | 1 |
| Hirobo | Shuttle ZX | 확인 | 1 | 1 |
| Hirobo | Shuttle ZXX | 확인 | 1 | 1 |
| Hirobo | SST-EAGLE4 EX EP SSLⅢ [0307-906] | 확인 | 1 | 7 |
| Hirobo | Turbulence D3 | 확인 | 1 | 5 |
| Hirobo | Turbulence D3 [0414-939] | 확인 | 1 | 5 |
| Hirobo | Turbulence D3 V2 | 확인 | 1 | 8 |
| Hirobo | Turbulence D3 V2 [0414-947] | 확인 | 1 | 8 |
| Hirobo | Turbulence D3 V3 [0414-951] | 확인 | 1 | 6 |
| Hirobo | UH-1B S30 | 확인 | 1 | 0 |
| JR PROPO | Ergo 32 | 확인 | 1 | 1 |
| JR PROPO | Ergo 36 | 확인 | 1 | 1 |
| JR PROPO | Ergo 46 | 확인 | 1 | 1 |
| JR PROPO | Ergo 60 | 확인 | 1 | 2 |
| JR PROPO | Ergo Z230 | 확인 | 1 | 2 |
| JR PROPO | Forza 450 | 확인 | 1 | 0 |
| JR PROPO | Forza 700 DFA | 확인 | 3 | 0 |
| JR PROPO | GSR260Z | 확인 | 1 | 5 |
| JR PROPO | NEX E6 | 확인 | 3 | 0 |
| JR PROPO | NEX E8 | 확인 | 1 | 7 |
| JR PROPO | Sylphide E12 | 확인 | 5 | 0 |
| JR PROPO | Venture 30 | 확인 | 1 | 4 |
| JR PROPO | Venture 50 CP | 확인 | 1 | 4 |
| JR PROPO | Vibe 50 | 확인 | 1 | 6 |
| JR PROPO | Vibe 50 NEX | 확인 | 1 | 5 |
| JR PROPO | Vibe 500E | 확인 | 3 | 0 |
| JR PROPO | Vibe 90 | 확인 | 1 | 6 |
| JR PROPO | Vibe 90 SG | 확인 | 1 | 8 |
| JR PROPO | Vigor | 확인 | 3 | 0 |
| JR PROPO | Voyager 50 | 확인 | 1 | 1 |
| JR PROPO | Voyager E | 확인 | 1 | 3 |
| KDS | Agile 7.2 | 확인 | 3 | 0 |
| KDS | Agile A3 | 확인 | 1 | 0 |
| KDS | Agile A7 | 확인 | 4 | 0 |
| KDS | Innova 700 | 확인 | 1 | 0 |
| Mikado | LOGO 200 | 확인 | 1 | 0 |
| Mikado | LOGO 200 V8 (2025) | 확인 | 1 | 0 |
| Mikado | LOGO 690 SX | 확인 | 1 | 0 |
| MSH / Protos | Protos 380 (Original / Release 1.3) | 확인 | 13 | 0 |
| MSH / Protos | Protos 380 EVO | 확인 | 7 | 0 |
| MSH / Protos | Protos 380 EVO V2 | 확인 | 13 | 0 |
| MSH / Protos | Protos 380 Standard | 확인 | 7 | 0 |
| MSH / Protos | Protos 380 Standard V2 | 확인 | 13 | 0 |
| MSH / Protos | Protos 480 | 확인 | 7 | 0 |
| MSH / Protos | Protos 500 | 확인 | 1 | 0 |
| MSH / Protos | Protos 700X Evoluzione | 확인 | 7 | 0 |
| MSH / Protos | Protos 700X Standard | 확인 | 7 | 0 |
| MSH / Protos | Protos 700X Ultra Light | 확인 | 7 | 0 |
| MSH / Protos | Protos Max V2 | 확인 | 7 | 0 |
| MSH / Protos | Protos Nitro | 확인 | 1 | 0 |
| OMPHOBBY | M1 | 확인 | 1 | 0 |
| OMPHOBBY | M1 EVO | 확인 | 1 | 0 |
| OMPHOBBY | M1 V1 (2025) | 확인 | 1 | 0 |
| OMPHOBBY | M1 V3 PRO | 확인 | 1 | 0 |
| OMPHOBBY | M2 (2019) | 확인 | 1 | 0 |
| OMPHOBBY | M2 EVO | 확인 | 1 | 0 |
| OMPHOBBY | M2 EVO MK2 | 확인 | 1 | 0 |
| OMPHOBBY | M2 Explore | 확인 | 1 | 0 |
| OMPHOBBY | M2 V2 | 확인 | 1 | 0 |
| OMPHOBBY | M2 V3 PRO | 확인 | 1 | 0 |
| OMPHOBBY | M2 V3 Sport | 확인 | 1 | 0 |
| OMPHOBBY | M4 | 확인 | 1 | 0 |
| OMPHOBBY | M4 MAX | 확인 | 1 | 0 |
| OMPHOBBY | M5 | 확인 | 9 | 0 |
| OMPHOBBY | M6 | 확인 | 6 | 0 |
| OMPHOBBY | M7 | 확인 | 6 | 0 |
| OMPHOBBY | M7R | 확인 | 6 | 0 |
| Outrage | Fusion 50 | 확인 | 1 | 0 |
| Outrage | Velocity 50 | 확인 | 3 | 0 |
| Outrage | Velocity 90 | 확인 | 1 | 0 |
| OXY / Lynx | OXY 2 SH | 확인 | 13 | 0 |
| OXY / Lynx | OXY 3 Sport | 확인 | 13 | 0 |
| OXY / Lynx | OXY 3 Tareq Edition (2018) | 확인 | 13 | 8 |
| OXY / Lynx | OXY 4 | 확인 | 15 | 0 |
| OXY / Lynx | OXY 4 MAX | 확인 | 4 | 0 |
| OXY / Lynx | OXY 5 | 확인 | 13 | 0 |
| OXY / Lynx | OXY 5 HF | 확인 | 9 | 0 |
| OXY / Lynx | OXY 5 MEG | 확인 | 13 | 0 |
| OXY / Lynx | OXY 5 Nitro / Nitroxy 5 | 확인 | 7 | 0 |
| SAB | Goblin 420 Raw | 확인 | 1 | 0 |
| SAB | Goblin 420 Raw Competition | 확인 | 13 | 0 |
| SAB | Goblin 500 | 확인 | 11 | 0 |
| SAB | Goblin 500 Raw | 확인 | 7 | 0 |
| SAB | Goblin 500 Sport | 확인 | 11 | 0 |
| SAB | Goblin 570 | 확인 | 19 | 0 |
| SAB | Goblin 570 KSE | 확인 | 10 | 0 |
| SAB | Goblin 570 Sport | 확인 | 19 | 0 |
| SAB | Goblin 580 Kraken | 확인 | 10 | 0 |
| SAB | Goblin 580 Kraken Nitro | 확인 | 4 | 0 |
| SAB | Goblin 580 Raw | 확인 | 10 | 0 |
| SAB | Goblin 580 Raw Nitro | 확인 | 4 | 0 |
| SAB | Goblin 630 | 확인 | 19 | 0 |
| SAB | Goblin 630 Competition | 확인 | 17 | 0 |
| SAB | Goblin 700 | 확인 | 19 | 0 |
| SAB | Goblin 700 Competition | 확인 | 9 | 0 |
| SAB | Goblin 700 Havok | 확인 | 17 | 0 |
| SAB | Goblin 700 Kraken | 확인 | 17 | 0 |
| SAB | Goblin 700 Kraken 3 Blades | 확인 | 9 | 0 |
| SAB | Goblin 700 Kraken S | 확인 | 17 | 0 |
| SAB | Goblin 700 Kraken S 3 Blades | 확인 | 9 | 0 |
| SAB | Goblin 700 KSE | 확인 | 17 | 0 |
| SAB | Goblin 700 Raw | 확인 | 1 | 0 |
| SAB | Goblin 700 Raw KSE | 확인 | 9 | 0 |
| SAB | Goblin 700 Raw Nitro | 확인 | 4 | 0 |
| SAB | Goblin 700 Raw Piuma | 확인 | 19 | 0 |
| SAB | Goblin 770 | 확인 | 17 | 0 |
| SAB | Goblin 770 Competition | 확인 | 17 | 0 |
| SAB | Goblin 770 Sport | 확인 | 17 | 0 |
| SAB | Goblin Black Nitro | 확인 | 4 | 0 |
| SAB | Goblin Black Thunder | 확인 | 9 | 0 |
| SAB | Goblin Black Thunder T | 확인 | 17 | 0 |
| SAB | Goblin Comet | 확인 | 17 | 0 |
| SAB | Goblin Fireball | 확인 | 1 | 0 |
| SAB | Goblin Fireball Havok | 확인 | 1 | 0 |
| SAB | Goblin Genesis F3C | 확인 | 9 | 0 |
| SAB | Goblin Genesis Sport | 확인 | 9 | 0 |
| SAB | Goblin Kraken 580 | 확인 | 10 | 0 |
| SAB | Goblin Maverick Sport | 확인 | 9 | 0 |
| SAB | Goblin Mini Comet | 확인 | 1 | 0 |
| SAB | Goblin Mini Genesis | 확인 | 13 | 0 |
| SAB | Goblin RAW 420 | 확인 | 1 | 0 |
| SAB | Goblin RAW 700 | 확인 | 1 | 0 |
| SAB | Goblin Speed | 확인 | 9 | 0 |
| SAB | Goblin Thunder Sport | 확인 | 17 | 0 |
| SAB | Goblin Urukay | 확인 | 17 | 0 |
| SAB | Goblin Urukay Carbon | 확인 | 33 | 0 |
| SAB | Goblin Urukay Competition | 확인 | 17 | 0 |
| SAB | Goblin Urukay Genesis | 확인 | 9 | 0 |
| SAB | Goblin Urukay Maverick | 확인 | 9 | 0 |
| SAB | Goblin Urukay WC | 확인 | 33 | 0 |
| SAB | ILGOBLIN 590 | 확인 | 22 | 0 |
| SAB | ILGoblin KSE | 확인 | 9 | 0 |
| SAB | ILGoblin Piuma | 확인 | 13 | 0 |
| SAB | IlGoblin Pro | 확인 | 9 | 0 |
| SAB | ILGoblin PRO 420 | 확인 | 13 | 0 |
| SAB | ILGoblin PRO 520 | 확인 | 7 | 0 |
| SAB | ILGoblin RAW | 확인 | 9 | 0 |
| XLPower | Nimbus 550 | 확인 | 4 | 0 |
| XLPower | Nimbus 550 V2 | 확인 | 1 | 0 |
| XLPower | Nimbus 550 V2 Nitro | 확인 | 5 | 0 |
| XLPower | Specter 700 | 확인 | 3 | 0 |
| XLPower | Specter 700 Nitro | 확인 | 2 | 0 |
| XLPower | Specter 700 Nitro Ultimate | 확인 | 1 | 0 |
| XLPower | Specter 700 V2 | 확인 | 1 | 0 |
| XLPower | Specter 700 V2 NME | 확인 | 9 | 0 |
| XLPower | Specter 700 V2 Ultimate | 확인 | 9 | 0 |
| XLPower | Specter 700 V2 WC | 확인 | 9 | 0 |
| XLPower | Stratos 200 | 확인 | 1 | 0 |
| XLPower | Stratos 200 3 Blade | 확인 | 1 | 0 |
| XLPower | Wraith E 760 V3 | 확인 | 1 | 0 |
| BEAM | E4 Advance | 확인 | 8 | 0 |
| GOOSKY | S1 new Edition | 확인 | 1 | 0 |
| Hirobo | Tsurugi | 확인 | 1 | 0 |
| Hirobo | Lepton EX | 확인 | 3 | 0 |
| Hirobo | Shuttle | 확인 | 3 | 0 |
| Hirobo | Sceadu Evolution EX | 확인 | 1 | 0 |
| Hirobo | Freya EX | 확인 | 2 | 6 |
| SAB | ILGOBLIN PIUMA NITRO | 확인 | 7 | 0 |
| ALZRC | Devil 465 Rigid | 확인 | 1 | 0 |
| ALIGN | T-REX 600 CF | 확인 | 2 | 0 |
| OXY / Lynx | OXY 2 | 확인 | 17 | 0 |
| JR PROPO | Ergo | 확인 | 3 | 0 |
| JR PROPO | Forza 600N | 확인 | 1 | 0 |
| JR PROPO | Airskipper 50 | 확인 | 1 | 0 |
| JR PROPO | Forza 700 Speed | 확인 | 1 | 0 |
| JR PROPO | NEX 550 | 확인 | 3 | 0 |
| Hirobo | SRB EC145 SC 4B（プロポレス）2.4GHz デジタル [0322-942] | 확인 | 1 | 0 |
| Hirobo | Embla 450E | 확인 | 2 | 0 |
| Hirobo | Shuttle シャトル Plus+2 エンジン/マフラーレス組立キット [0412-975] | 확인 | 1 | 0 |
| Hirobo | Shuttle Plus 2 | 확인 | 2 | 0 |
| Hirobo | SDX | 확인 | 5 | 0 |
| Hirobo | SDX 50 | 확인 | 5 | 0 |
| KDS | Chase 360 | 확인 | 2 | 0 |
| Hirobo | Eagle 3 WC | 확인 | 4 | 0 |
| Hirobo | Eagle 3 SWM | 확인 | 3 | 0 |
| ALIGN | T-REX 600 GF | 확인 | 2 | 0 |
| JR PROPO | Vibe 50 NEX FBL | 확인 | 1 | 0 |
| Hirobo | Eagle 4 EP | 확인 | 1 | 0 |
| Hirobo | GPH 346 | 확인 | 1 | 9 |
| ALIGN | T-Rex 450 | 확인 | 22 | 0 |
| ALIGN | T-Rex 500 | 확인 | 9 | 0 |
| Hirobo | Lama SA315 | 확인 | 4 | 0 |
| Hirobo | EC120 | 확인 | 2 | 0 |
| Hirobo | Eagle 3 EP SSL | 확인 | 4 | 0 |
| Hirobo | Eagle 2 | 확인 | 2 | 0 |
| Hirobo | Eagle 2 EX | 확인 | 2 | 0 |
| Hirobo | Shuttle Sceadu | 확인 | 3 | 0 |
| JR PROPO | Vibe | 확인 | 2 | 0 |
| JR PROPO | Venture | 확인 | 3 | 0 |
| JR PROPO | Voyager | 확인 | 2 | 0 |
| ALZRC | Devil 420 FAST | 확인 | 2 | 0 |
| ALZRC | Devil 450 Pro | 확인 | 2 | 0 |
| XLPower | Wraith E | 확인 | 3 | 0 |
| Avant | Mostro | 확인 | 5 | 0 |
| ALIGN | T-Rex 600 | 확인 | 6 | 0 |
| ALIGN | T-Rex 700 | 확인 | 15 | 0 |
| FLYWING | AS350 ACE | 확인 | 2 | 0 |
| FLYWING | Bell407 ACE 4-Blade | 확인 | 2 | 0 |
| JR PROPO | Vigor 60 | 확인 | 3 | 0 |
| KDS | Innova 600 | 확인 | 2 | 0 |
| FLYWING | EC135 ACE | 확인 | 2 | 0 |
| FLYWING | BO105 ACE | 확인 | 2 | 0 |
| FLYWING | Bell412 ACE | 확인 | 2 | 0 |
| FLYWING | MH-60 ACE | 확인 | 2 | 0 |
| FLYWING | Bell206 ACE 2-Blade | 확인 | 2 | 0 |
| ALIGN | E1 900 PLUS (Tri-Blades Rotor Head) | 확인 | 2 | 0 |
| ALIGN | T-REX 600E PRO DFC | 확인 | 3 | 0 |
| OXY / Lynx | OXY 2 Factory Edition | 확인 | 17 | 0 |
| Mikado | LOGO 700 XXTREME | 확인 | 4 | 0 |
| FLYWING | FW450L V3 | 확인 | 2 | 0 |
| FLYWING | UH-1 V4 | 확인 | 2 | 0 |
| FLYWING | UH-1 ACE 2-Blade | 확인 | 2 | 0 |
| FLYWING | Bell206 ACE 4-Blade | 확인 | 2 | 0 |
| GOOSKY | RS5 Ultra | 확인 | 4 | 0 |
| GOOSKY | E7 | 확인 | 2 | 0 |
| ALZRC | Devil 480 Rigid | 확인 | 2 | 0 |
| ALZRC | Devil 480 FAST | 확인 | 2 | 0 |
| OXY / Lynx | OXY 2 Sport | 확인 | 17 | 0 |
| ALIGN | T-REX 450 PRO DFC | 확인 | 2 | 0 |
| ALIGN | T-rex 100 | 확인 | 2 | 0 |
| JR PROPO | Forza 450 EX | 확인 | 2 | 0 |
| JR PROPO | Sylphide E12 755 | 확인 | 5 | 0 |
| JR PROPO | Forza 700 | 확인 | 3 | 0 |
| JR PROPO | Airskipper 90 CE | 확인 | 2 | 0 |
| XLPower | Nimbus 550 Nitro | 확인 | 4 | 0 |
| XLPower | XL550 | 확인 | 3 | 0 |
| MSH / Protos | Mini Protos 450 | 확인 | 6 | 0 |
| Outrage | Outrage 550 | 확인 | 2 | 0 |
| OXY / Lynx | OXY 3 | 확인 | 6 | 0 |
| OXY / Lynx | OXY 3 Qube | 확인 | 7 | 0 |
| JR PROPO | Ergo 30 | 확인 | 2 | 0 |
| ALIGN | E1 V2 (Two-Blade Rotor Head) | 확인 | 2 | 0 |
| ALIGN | E1 900 Multi-Functional Helicopter | 확인 | 2 | 0 |
| ALIGN | E1 900 PLUS (Two-Blade Rotor Head) | 확인 | 2 | 0 |
| ALIGN | E1 V2 (Tri-Blades Rotor Head) | 확인 | 2 | 0 |
| JR PROPO | Airskipper 50 Type II | 확인 | 3 | 0 |
| JR PROPO | Sylphide 90 | 확인 | 2 | 0 |
| OXY / Lynx | OXY 3 Stretch | 확인 | 6 | 0 |
| GAUI | X7 Formula | 확인 | 4 | 0 |
| MSH / Protos | Protos Max V2 Evoluzione | 확인 | 7 | 0 |
| Outrage | G5 | 확인 | 4 | 0 |
| Outrage | 550 | 확인 | 2 | 0 |
| XLPower | XL380 V2 | 확인 | 7 | 0 |
| XLPower | XL380 | 확인 | 7 | 0 |
| GAUI | X4 II Formula | 확인 | 7 | 0 |
| FLYWING | Bell 206 V3 | 확인 | 2 | 0 |
| GAUI | Hurricane 255 | 확인 | 2 | 0 |
| FLYWING | FW200 | 확인 | 2 | 0 |
| Hirobo | Lama Petrol | 확인 | 2 | 0 |
| Mikado | LOGO 20 | 확인 | 6 | 0 |
| FLYWING | UH-1 V3 | 확인 | 2 | 0 |
| Hirobo | Bell AH-1S Cobra | 확인 | 2 | 0 |
| JR PROPO | Airskipper 90 CF | 확인 | 2 | 0 |
| JR PROPO | Airskipper 90 | 확인 | 2 | 0 |
| XLPower | XL520 | 확인 | 3 | 0 |
| FLYWING | UH-1 ACE 4-Blade | 확인 | 2 | 0 |
| FLYWING | Bell 206 V4 | 확인 | 2 | 0 |
| KDS | Innova 550 | 확인 | 2 | 0 |
| OXY / Lynx | OXY Flash | 확인 | 25 | 0 |
| Outrage | Velocity 50 N2 | 확인 | 2 | 0 |
| Mikado | GLOGO 690 SX | 확인 | 2 | 0 |
| Hirobo | Bell 222 | 확인 | 2 | 0 |
| MSH / Protos | Protos 500 Carbon | 확인 | 9 | 0 |
| XLPower | Wraith E 760 V1 | 확인 | 7 | 0 |
| KDS | Agile A5 | 확인 | 2 | 0 |
| ALIGN | T-REX 100X | 확인 | 2 | 0 |
| ALIGN | T-REX 450X | 확인 | 4 | 0 |
| KDS | 450SD | 확인 | 2 | 0 |
| KDS | Innova 450 | 확인 | 2 | 0 |
| Hirobo | Eagle | 확인 | 2 | 0 |
| SAB | ILGoblin Competizione | 확인 | 17 | 0 |
| SAB | ILGoblin Competizione Nitro | 확인 | 7 | 0 |
| Hirobo | 30 Scale Body – BELL 222 [0412-955] | 확인 | 3 | 0 |
| Hirobo | 30 Scale Body – Long Ranger [0412-903] | 확인 | 3 | 0 |
| Hirobo | 30 Scale Body – Jet Ranger [0412-908] | 확인 | 3 | 0 |
| Hirobo | 50 Scale Body – BELL222 [0403-960] | 확인 | 3 | 0 |
| Hirobo | 50 Scale Body – HUGHES 500MD DEFENDER [0403-948] | 확인 | 3 | 0 |
| Hirobo | 50 Scale Body – JetRanger [0403-958] | 확인 | 3 | 0 |
| Hirobo | 50 Scale Body – LongRanger [0403-959] | 확인 | 3 | 0 |
| Hirobo | 50 Scale Body – MD500E [0403-946] | 확인 | 3 | 0 |
| Hirobo | 60 Scale Body – JetRanger [0404-984] | 확인 | 3 | 0 |
| Hirobo | 60 Scale Body – BELL222 [0414-920] | 확인 | 3 | 0 |
| Hirobo | Agusta A109 | 확인 | 4 | 0 |
| Hirobo | Ecureuil | 확인 | 4 | 0 |
| Hirobo | Shuttle JetRanger | 확인 | 4 | 0 |
| Hirobo | Condor | 확인 | 2 | 0 |
| Hirobo | Stork - Hawk | 확인 | 2 | 0 |
| Hirobo | Shuttle RG | 확인 | 2 | 0 |
| Mikado | LOGO 600 SE 2010-2013 | 확인 | 7 | 0 |
| Mikado | LOGO 500 SE 2009-2012 | 확인 | 2 | 14 |
| KDS | Agile 5.5 | 확인 | 2 | 0 |
| GAUI | R5 | 확인 | 3 | 6 |
| KDS | 450S | 확인 | 2 | 3 |
| SAB | Goblin 420 | 확인 | 7 | 1 |
| KDS | 450C | 확인 | 2 | 0 |
| KDS | 450SV | 확인 | 2 | 0 |
| ALZRC | Devil 450 Rigid | 미확인 초안 | 0 | 0 |
| ALZRC | Devil 450 Sport | 참고값·미검증 | 0 | 0 |
| ALZRC | Devil 450L | 미확인 초안 | 0 | 0 |
| ALZRC | Devil 500 Pro | 참고값·미검증 | 0 | 2 |
| Avant | Aurora | 미확인 초안 | 0 | 0 |
| Avant | Aurora 90 Electric | 참고값·미검증 | 0 | 4 |
| Avant | Aurora 90 Nitro | 참고값·미검증 | 0 | 0 |
| Avant | Aurora Ultimate | 미확인 초안 | 0 | 0 |
| Avant | Mostro 700 Nitro | 참고값·미검증 | 0 | 4 |
| BEAM | E6 Avantgarde | 참고값·미검증 | 0 | 0 |
| FLYWING | Airwolf ACE | 참고값·미검증 | 0 | 0 |
| FLYWING | Bell 206 V2 | 참고값·미검증 | 0 | 0 |
| FLYWING | FW450 | 미확인 초안 | 0 | 0 |
| FLYWING | FW450 V2 | 미확인 초안 | 0 | 0 |
| FLYWING | FW450L V2 | 미확인 초안 | 0 | 0 |
| FLYWING | FW450L V2.5 | 미확인 초안 | 0 | 0 |
| GARTT | GT450L | 참고값·미검증 | 0 | 0 |
| GARTT | GT500 | 참고값·미검증 | 0 | 0 |
| GARTT | GT550 | 미확인 초안 | 0 | 0 |
| GARTT | GT600 | 미확인 초안 | 0 | 0 |
| GARTT | GT700 | 미확인 초안 | 0 | 0 |
| GARTT | GT700 DFC | 미확인 초안 | 0 | 0 |
| GARTT | GT800 | 미확인 초안 | 0 | 0 |
| GARTT | GT800 DFC | 미확인 초안 | 0 | 0 |
| GAUI | EP100 | 미확인 초안 | 0 | 0 |
| GAUI | EP200 | 미확인 초안 | 0 | 0 |
| GAUI | Hurricane 200 | 미확인 초안 | 0 | 0 |
| GAUI | Hurricane 200 V2 | 참고값·미검증 | 0 | 0 |
| GAUI | Hurricane 550 SE | 참고값·미검증 | 0 | 0 |
| GAUI | NEX6 | 참고값·미검증 | 0 | 3 |
| GAUI | X2 | 참고값·미검증 | 0 | 0 |
| GAUI | X2 Formula | 참고값·미검증 | 0 | 0 |
| GAUI | X5 V2 | 참고값·미검증 | 0 | 0 |
| GOOSKY | RS4 | 참고값·미검증 | 0 | 0 |
| GOOSKY | RS4 Venom | 참고값·미검증 | 0 | 0 |
| Hirobo | Bell 47G2 | 참고값·미검증 | 0 | 0 |
| Hirobo | Bell UH-1B | 미확인 초안 | 0 | 0 |
| Hirobo | Corvette | 미확인 초안 | 0 | 0 |
| Hirobo | Dauphin | 참고값·미검증 | 0 | 0 |
| Hirobo | Eagle 3 EP AOCC | 참고값·미검증 | 0 | 0 |
| Hirobo | Eagle 3 WC SSL | 미확인 초안 | 0 | 0 |
| Hirobo | Enstrom Shark | 참고값·미검증 | 0 | 0 |
| Hirobo | Falcon | 미확인 초안 | 0 | 0 |
| Hirobo | Falcon 5 series | 미확인 초안 | 0 | 0 |
| Hirobo | Falcon 7 series | 미확인 초안 | 0 | 0 |
| Hirobo | Falcon 8 series | 미확인 초안 | 0 | 0 |
| Hirobo | Falcon MK2 | 미확인 초안 | 0 | 0 |
| Hirobo | Five Star | 미확인 초안 | 0 | 0 |
| Hirobo | FREYA Evolution OP SWM SSZ-Ⅴ ブレードレス [0414-950] | 미확인 초안 | 0 | 0 |
| Hirobo | Gazelle | 미확인 초안 | 0 | 0 |
| Hirobo | GPH 50 | 참고값·미검증 | 0 | 0 |
| Hirobo | Hovermate | 미확인 초안 | 0 | 0 |
| Hirobo | JetRanger | 미확인 초안 | 0 | 0 |
| Hirobo | JetRanger 40 | 미확인 초안 | 0 | 0 |
| Hirobo | JetRanger 60 | 미확인 초안 | 0 | 0 |
| Hirobo | JetRanger SST | 미확인 초안 | 0 | 0 |
| Hirobo | KV107 Vertol | 미확인 초안 | 0 | 0 |
| Hirobo | Lama - Fladbed | 미확인 초안 | 0 | 0 |
| Hirobo | Lama electric | 참고값·미검증 | 0 | 0 |
| Hirobo | MH-10 | 참고값·미검증 | 0 | 0 |
| Hirobo | Mini Star | 미확인 초안 | 0 | 0 |
| Hirobo | UH - 1B 40 | 미확인 초안 | 0 | 0 |
| Hirobo | UH-1B 60 | 미확인 초안 | 0 | 0 |
| Hirobo | UH-1B GX20 | 미확인 초안 | 0 | 0 |
| JR PROPO | Airskipper 30 | 참고값·미검증 | 0 | 1 |
| JR PROPO | Ergo 50 | 참고값·미검증 | 0 | 0 |
| JR PROPO | Sylphide 50 | 미확인 초안 | 0 | 0 |
| JR PROPO | Sylphide 90 II | 미확인 초안 | 0 | 0 |
| JR PROPO | Sylphide E12 EX | 참고값·미검증 | 0 | 0 |
| JR PROPO | Vigor 90 | 미확인 초안 | 0 | 0 |
| KDS | 450QS | 참고값·미검증 | 0 | 0 |
| KDS | Agile 7.2 Stretch | 미확인 초안 | 0 | 0 |
| Mikado | LOGO 10 | 참고값·미검증 | 0 | 1 |
| Mikado | LOGO 10 3D | 참고값·미검증 | 0 | 1 |
| Mikado | LOGO 14 | 참고값·미검증 | 0 | 0 |
| Mikado | LOGO 16 | 참고값·미검증 | 0 | 0 |
| Mikado | LOGO 24 | 참고값·미검증 | 0 | 0 |
| Mikado | LOGO 400 | 참고값·미검증 | 0 | 2 |
| Mikado | LOGO 400 bis 2008 | 참고값·미검증 | 0 | 2 |
| Mikado | LOGO 400 SE | 참고값·미검증 | 0 | 2 |
| Mikado | LOGO 480 XXTREME | 참고값·미검증 | 0 | 8 |
| Mikado | LOGO 500 | 참고값·미검증 | 0 | 0 |
| Mikado | LOGO 500 DX | 참고값·미검증 | 0 | 21 |
| Mikado | LOGO 550 | 참고값·미검증 | 0 | 2 |
| Mikado | LOGO 550 SE | 참고값·미검증 | 0 | 6 |
| Mikado | LOGO 550 SX | 참고값·미검증 | 0 | 6 |
| Mikado | LOGO 580 (2026) | 참고값·미검증 | 0 | 0 |
| Mikado | LOGO 600 | 참고값·미검증 | 0 | 2 |
| Mikado | LOGO 600 3D | 참고값·미검증 | 0 | 21 |
| Mikado | LOGO 600 DX | 참고값·미검증 | 0 | 21 |
| Mikado | LOGO 600 SE | 참고값·미검증 | 0 | 6 |
| Mikado | LOGO 600 SX | 참고값·미검증 | 0 | 6 |
| Mikado | LOGO 700 | 참고값·미검증 | 0 | 7 |
| Mikado | LOGO 700 V2 | 참고값·미검증 | 0 | 0 |
| Mikado | LOGO 800 | 참고값·미검증 | 0 | 0 |
| Mikado | LOGO 800 XXTREME | 참고값·미검증 | 0 | 4 |
| MSH / Protos | Protos 500 Stretch | 참고값·미검증 | 0 | 6 |
| MSH / Protos | Protos Max V1 | 미확인 초안 | 0 | 0 |
| Outrage | Velocity 90 N2 | 미확인 초안 | 0 | 0 |
| OXY / Lynx | OXY 3 Tareq Edition (2015) | 참고값·미검증 | 0 | 8 |
| SAB | Goblin 380 | 참고값·미검증 | 0 | 1 |
| SAB | Goblin 380 Buddy | 참고값·미검증 | 0 | 1 |
| SAB | Goblin 380 KSE | 참고값·미검증 | 0 | 1 |
| XLPower | Wraith E 760 V2 | 참고값·미검증 | 0 | 0 |
