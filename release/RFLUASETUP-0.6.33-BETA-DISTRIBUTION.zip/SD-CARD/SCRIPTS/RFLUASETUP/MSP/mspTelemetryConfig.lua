local function getTelemetryConfig(callback, callbackParam)
    local message = {
        command = 73, -- MSP_TELEMETRY_CONFIG
        processReply = function(self, buf)
            local config = {}
            --rf2.print("buf length: "..#buf)
            local offOnTable = { [0] = "OFF", "ON" }
            config.telemetry_inverted = { value = rf2.mspHelper.readU8(buf), min = 0, max = 1, table = offOnTable }
            config.telemetry_halfduplex = { value = rf2.mspHelper.readU8(buf), min = 0, max = 1, table = offOnTable }
            config.telemetry_sensors = { value = rf2.mspHelper.readU32(buf) }
            if rf2.apiVersion >= 12.07 then
                config.telemetry_pinswap = { value = rf2.mspHelper.readU8(buf), min = 0, max = 1, table = offOnTable }
                config.crsf_telemetry_mode = { value = rf2.mspHelper.readU8(buf), min = 0, max = 1, table = { [0] = "NATIVE", "CUSTOM" } }
                config.crsf_telemetry_rate = { value = rf2.mspHelper.readU16(buf), min = 0, max = 50000 }
                config.crsf_telemetry_ratio = { value = rf2.mspHelper.readU16(buf), min = 0, max = 50000 }
                config.crsf_telemetry_sensors = {}
                for i = 1, 40 do
                    config.crsf_telemetry_sensors[i] = rf2.mspHelper.readU8(buf)
                    --rf2.print(tostring(config.crsf_telemetry_sensors[i]))
                end
            end

            callback(callbackParam, config)
        end,
        
    }
    rf2.mspQueue:add(message)
end

return {
    getTelemetryConfig = getTelemetryConfig
}
